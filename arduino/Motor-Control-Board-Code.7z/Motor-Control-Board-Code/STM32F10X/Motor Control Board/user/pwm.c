#include "pwm.h"

//arr��Reload value
//psc��Clock Prescaler
void TIM3_PWM_Init(u16 arr,u16 psc)
{  
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	//Enable Timer3 Clock
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB  | RCC_APB2Periph_AFIO, ENABLE);
	
	GPIO_PinRemapConfig(GPIO_PartialRemap_TIM3, ENABLE); //Timer3 Partial Remap  TIM3_CH2->PB5    
 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
 
	TIM_TimeBaseStructure.TIM_Period = arr; //Reload Register Cycle Value
	TIM_TimeBaseStructure.TIM_Prescaler =psc; //Timer3 Pre Frequency Value 
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //Clock Division:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); 
		 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2; //Timer PWM Mode 2
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //Compare Output Enable
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //Output Compare High Polarity
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);  

	TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);  //Enable Preload Register
 
	TIM_Cmd(TIM3, ENABLE); 
	

}
